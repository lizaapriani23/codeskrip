<div class='row-fluid'>
	<div class='span12'>
		<div class='page-header'>
			<h1 class='pull-left'>
				<img src="../assets/images/logo1.jpg" width="80" height="80">
				<span>Pemilihan Warga Penerima Bantuan Pangan Non Tunai</span>
			</h1>
			<div class='pull-right'>
				<ul class='breadcrumb'>
					<li><a href="#"><i class='icon-calender'></i></a></li>
					<li class='separator'></li>
					<li><?php echo "$hari_ini, $tanggal | $jam WIB"; ?></li>
				</ul>
			</div>
		</div>
	</div>
</div>