<?php
include "head.php";
?>
<body class='contrast-red '>

<?php include_once 'navbar.php'; ?>

<div id='wrapper'>
  <div id='main-nav-bg'></div>
  <nav class='' id='main-nav'>
    <div class='navigation'>
    <?php
    include "sidebar.php";
    ?>
    </div>
  </nav>
<section id='content'>
<div class='container-fluid'>
<div class='row-fluid' id='content-wrapper'>
<div class='span12'>
  
  <?php include_once 'header.php'; ?>

  <div class='row-fluid'>
    <div class='span12 box'>
      <div class='box-content'>
        <labeltxt><p style='text-align:right'>Selamat datang <b><?php echo $_SESSION['nama'];?></b> di halaman Admin.<br></p></labeltxt>
      <h3>Latar Belakang</h3>
      <p style='text-align:justify; text-indent:20px'>Bantuan Pangan Non Tunai (BPNT) adalah bantuan pangan dari pemerintah yang diberikan kepada Keluarga Penerima Manfaat setiap bulannya melalui mekanisme akun elektronik yang digunakan hanya untuk membeli pangan di Warung Kelompok Usaha Bersama Keluarga Harapan, BPNT diberikan sebulan sekali. Pemilihan penerima bantuan pangan masih bersifat subjektif, sehingga menimbulkan permasalahan diatara warga.<sup>[1]</sup></p>
      <p style='text-align:justify; text-indent:20px'>pengambilan keputusan calon penerima BPNT di Kelurahan Baranangsiang Bogor Timur masih menggunakan cara manual dan data-data yang dikumpulkan cukup banyak sehingga petugas membutuhkan waktu yang lama untuk memilih siapa saja yang tepat untuk mendapatkan bantuan
                  <sup>[1]</sup> 
      <p><b>Sistem Pengambilan Keputusan</b> adalah sistem informasi berbasis komputer yang dipakai untuk mendukung pengambilan keputusan dalam suatu organisasi atau perusahaan.</p>
                    <p style='text-align:justify; text-indent:20px'>oleh karena itu dibuatlah Sistem Pengambilan Keputusan Bantuan Sosial ini untuk membantu menentukan penerima Bansos Bantuan Pangan Non Tunai di Kelurahan Baranangsiang </p>
     
        <div class='clearfix'></div>

        <hr class='hr-normal' />
        <br>
       
      </div>
    </div>
  </div>

</div>
</div>
</div>
</section>
</div>

<?php
include "footer.php";
?>