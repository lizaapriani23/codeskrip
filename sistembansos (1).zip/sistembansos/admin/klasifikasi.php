<?php include_once '../admin/head.php'; ?>
<body class="contrast-red">

<?php include_once 'navbar.php'; ?>

<div id="wrapper">
	<div id="main-nav-bg"></div>
	<nav class="" id="main-nav">
		<div class="navigation">
			<?php include_once "../admin/sidebar.php"; ?>
		</div>
	</nav>

	<section id="content">
		<div class="container-fluid">
			<div class="row-fluid" id="content-wrapper">
				<div class="span12">
					
				<?php include_once "header.php"; ?>


<?php 
if (!empty($_POST['btnSimpan'])) {
	# hapus semua data klasifikasi pada guru tertentu
	mysqli_query($konek,"DELETE FROM tbl_klasifikasi WHERE warga_id='".$_POST['warga']."'");
	$q=mysqli_query($konek,"SELECT * FROM tbl_kriteria");
	if (mysqli_num_rows($q) > 0) {
		if ($h=mysqli_fetch_array($q)) {
			# insert data klasifikasi
			if (!empty($_POST['usia_'.$h['id_kriteria']])) {
				mysqli_query($konek,"INSERT INTO tbl_klasifikasi(warga_id,pendapatan_id,status_id, tanggungan_id, usia_id) VALUES('".$_POST['warga']."','".$_POST['usia_8']."','".$_POST['usia_9']."','".$_POST['usia_7']."','".$_POST['usia_6']."')");
			}
		}
	}
	echo "<script>alert('Data berhasil tersimpan');location.href='klasifikasi.php';</script>";
}

$q=mysqli_query($konek,"SELECT * FROM tbl_warga ORDER BY id_warga");
if (mysqli_num_rows($q)>0) {
	while ($h=mysqli_fetch_array($q)) {
		$daftarKriteria='';
		$n=0;
		# menampilkan data kriteria untuk tiap guru
		$qq=mysqli_query($konek,"SELECT * FROM tbl_kriteria");
		if (mysqli_num_rows($qq)>0) {
			while ($hh=mysqli_fetch_array($qq)) {
				# menampilkan data himpunan untuk dimasukan ke dalam combobox kriteria
				$listKriteria='<option value=""></option>';
				$usia=mysqli_query($konek,"SELECT * FROM tbl_usia WHERE id_kriteria='".$hh['id_kriteria']."'");
				$tang=mysqli_query($konek,"SELECT * FROM tbl_tanggungan WHERE id_kriteria='".$hh['id_kriteria']."'");
				$pend=mysqli_query($konek,"SELECT * FROM tbl_pendapatan WHERE id_kriteria='".$hh['id_kriteria']."'");
				$statNikah=mysqli_query($konek,"SELECT * FROM tbl_status_pernikahan WHERE id_kriteria='".$hh['id_kriteria']."'");
				if (mysqli_num_rows($usia)>0) {
					while ($hhh=mysqli_fetch_array($usia)) {
						if (mysqli_num_rows(mysqli_query($konek,"SELECT * FROM tbl_klasifikasi WHERE warga_id='".$h['id_warga']."' AND usia_id='".$hhh['id']."'"))>0) {
							# merupakan himpunan yang terpilih/ tersimpan
							$s=' selected';
						}else{
							$s='';
						}
						$listKriteria.='<option value="'.$hhh['id'].'"'.$s.'>'.$hhh['nama'].'</option>';
						
					}
				}
				if(mysqli_num_rows($tang)>0){
					while ($tanggungan = mysqli_fetch_array($tang)) {
						if (mysqli_num_rows(mysqli_query($konek,"SELECT * FROM tbl_klasifikasi where warga_id='".$h['id_warga']."' AND tanggungan_id='".$tanggungan['id']."'"))>0) {
							// code...
							$s=' selected';
						}else{
							$s='';
						}
						$listKriteria.='<option value="'.$tanggungan['id'].'"'.$s.'>'.$tanggungan['nama'].'</option>';
					}
				} 

				if(mysqli_num_rows($pend)>0){
					while ($pendapatan = mysqli_fetch_array($pend)) {
						if (mysqli_num_rows(mysqli_query($konek,"SELECT * FROM tbl_klasifikasi where warga_id='".$h['id_warga']."' AND pendapatan_id='".$pendapatan['id']."'"))>0) {
							// code...
							$s=' selected';
						}else{
							$s='';
						}
						$listKriteria.='<option value="'.$pendapatan['id'].'"'.$s.'>'.$pendapatan['nama'].'</option>';
					}
				} 

				if(mysqli_num_rows($statNikah)>0){
					while ($statusnikah = mysqli_fetch_array($statNikah)) {
						if (mysqli_num_rows(mysqli_query($konek,"SELECT * FROM tbl_klasifikasi where warga_id='".$h['id_warga']."' AND status_id='".$statusnikah['id']."'"))>0) {
							// code...
							$s=' selected';
						}else{
							$s='';
						}
						$listKriteria.='<option value="'.$statusnikah['id'].'"'.$s.'>'.$statusnikah['nama'].'</option>';
					}
				} 
				$n++;
				$input='<select name="usia_'.$hh['id_kriteria'].'">'.$listKriteria.'</select>';
				$input2='<select name="usia_'.$hh['id_kriteria'].'">'.$listKriteria.'</select>';
				// $input2='<select name="himpunan_'.$hh['id_kriteria'].'">'.$listKriteria.'</select>';

				// echo($hh['nama_kriteria'] . '<br>');
				$daftarKriteria.='
				<tr>
					<td width="120">'.$hh['nama_kriteria'].'</td>
					<td>'.$hh['id_kriteria'].$input.'</td>
				</tr>
				';
			}
		}

		$no++;

		$daftar.='
		<tr>
			<td align="center" valign="top"><center>'.$no.'</center></td>
			<td align="center" valign="top"><center>'.$h['nik'].'</center></td>
			<td align="center" valign="top"><center>'.$h['nama'].'</center></td>
			<td align="center" valign="top"><center>'.$h['kepala_keluarga'].'</center></td>
			<td align="center" valign="top"><center><span id="cmd_'.$h['id_warga'].'"><strong>Edit Klasifikasi</strong></span></center></td>
		</tr>

		<tr>
		<td valign="top" colspan="5">
		<form action="" name="" method="post" id="kla_'.$h['id_warga'].'" style="display:none">
		<input name="warga" type="hidden" value="'.$h['id_warga'].'" />
			<table class="table" style="margin-bottom:0;">
				<!--<tr>
				<td colspan="2"><strong>'.$no.'. '.strtoupper($h['nama']).'</strong></td>
			  </tr>-->
			'.$daftarKriteria.'
			<tr>
				<td width="140"></td>
				<td><input name="btnSimpan" class="btn btn-danger" type="submit" value="Simpan"></td>
			</tr>
			</table>
		</form>
		</td>
		</tr>
		';

		$js.="
		$('#cmd_".$h['id_warga']."').css( 'cursor', 'pointer' );
		$('#cmd_".$h['id_warga']."').click(function() {
			$('#kla_".$h['id_warga']."').toggle('slow', function() {				
			});
		});
		";
	}
}

?>



				<div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class="span12 box bordered-box orange-border" style="margin-bottom: 0;">
									<h3>Klasifikasi</h3>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<table class="table" style="margin-bottom: 0;">
												<thead>
													<tr>
														<th><center>No.</center></th>
														<th><center>NIK</center></th>
														<th><center>NAMA</center></th>
														<th><center>KEPALA KELUARGA</center></th>
														<th><center>AKSI</center></th>
													</tr>
												</thead>
												<tbody>
													<?php echo $daftar; ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
							<hr class="hr-normal"/>
						</div>
					</div>
				</div>

				</div>
			</div>
		</div>
	</section>

</div>

<!-- toggle edit klasifikasi -->
<script type="text/javascript" src="../assets/js/jquery-1.3.1.min.js"></script>
<script language="JavaScript" type="text/javascript">
	<?php echo $js; ?>
</script>

<?php include_once 'footer.php'; ?>
