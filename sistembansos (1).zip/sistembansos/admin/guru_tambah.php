<?php 
include_once 'head.php';
?>
<body class='contrast-red'>
	<?php include_once 'navbar.php'; ?>

<div id='wrapper'>
	<div id='main-nav-bg'></div>
	<nav class='' id='main-nav'>
		<div class='navigation'>
			<?php include_once 'sidebar.php'; ?>
		</div>
	</nav>
	<section id='content'>
		<div class='container-fluid'>
			<div class='row-fluid' id='content-wrapper'>
				<div class='span12'>
					<?php include_once 'header.php'; ?>
					
					<div class='row-fluid'>
				    <div class='span12 box'>
			        <div class='box-content'>
								<h3>Tambah Warga</h3>
								<form method='POST' action='guru_tambah.php'>
								<table align='left'>
									<tr>
										<td>NIK KPM</td>
										<td> : </td>
										<td><input type=text name='nik' placeholder='masukan NIK penerima' required></td>
									</tr>			
									<tr>
										<td>NAMA KPM</td>
										<td> : </td>
										<td><input type=text name='namawarga' placeholder='masukan nama penerima' required></td>
									</tr>
									<tr>
										<td>RT</td>
										<td>:</td>
										<td><input type="text" name="rt" placeholder='rt' required>
											<!--<select name="jenkel">
												<option value="">-Pilih-</option>
												<option value="L">1</option>
												<option value="P">2</option>
												<option value="P">3</option>
												<option value="P">4</option>
												<option value="P">5</option>
												<option value="P">6</option>
											</select> -->
										</td>
									</tr>
	                <tr>
	                    <td>RW</td>
	                    <td>:</td>
	                    <td><input type=text name='rw' placeholder='rw' required></td>
	                </tr>
	                <tr>
	                    <td>Jalan</td>
	                    <td>:</td>
	                    <td>
							<input type="text" name='jalan' placeholder='Jalan' required>
	                    <!-- <div class='datepicker input-append' id='datepicker'>
	                        <input class='input-medium' data-format='dd-MM-yyyy' placeholder='Jalan' type=text name='tgl_lahir' />
	                        <span class='add-on'>
	                            <i data-date-icon='icon-calendar' data-time-icon='icon-time'></i>
	                        </span>
	                    </div> -->
	                    </td>
	                </tr>
	                <tr>
	                    <td>Nama Kepala Keluarga</td>
	                    <td>:</td>
	                    <td><input type=text name='kepala_keluarga' placeholder='masukan nama kepala keluarga' /></td>
	                </tr>
									<tr>
										<td>&nbsp;</td>
										<td>&nbsp;</td>
										<td>&nbsp;</td>
									<tr>
									<tr>
										<td colspan=3>
										<button class='btn btn-danger' name="simpan" type='submit'><i class='icon-save'></i> Simpan</button>
                    <button class='btn' onclick=self.history.back() type='button'>Batal</button>
										</td>
									</tr>
								</table>
								</form>
				<?php
				if(isset($_POST['simpan'])){
				    // $tgl = date("Y-m-d",strtotime($_POST['tgl_lahir']));
					$jalan = $_POST['jalan'];
				    $cek_data = mysqli_num_rows(mysqli_query($konek,"SELECT * FROM tbl_warga WHERE nik='$_POST[nik]'"));
				    if ($cek_data > 0){
				        echo "<script>window.alert('Data NIK sudah ada! NIK tidak boleh sama, Mohon ulangi.');
				                window.location=(href='guru_tambah.php')</script>";
				    } else {
				        $sql = "INSERT INTO tbl_warga VALUES('','$_POST[nik]','$_POST[namawarga]','$_POST[rt]',
				                '$_POST[rw]','$jalan','$_POST[kepala_keluarga]')";
				        $query = mysqli_query($konek,$sql) or die(mysqli_error());
				        if($query) {
				        echo "<script>window.alert('Data warga berhasil ditambah');
				            window.location=(href='guru.php')</script>";
				        }
				    }
				}
				?>
			            <div class='clearfix'></div>
			            <hr class='hr-normal' />
			        </div>
				    </div>
					</div>

				</div>
			</div>
		</div>
	</section>
</div>

<?php include_once 'footer.php'; ?>