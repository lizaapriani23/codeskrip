<?php include_once 'head.php'; ?>

<body class="contrast-red">
	<?php include_once 'navbar.php'; ?>

	<div id="main-nav-bg"></div>
	<nav class="" id="main-nav">
		<div class="navigation">
			<?php include_once 'sidebar.php'; ?>
		</div>
	</nav>

	<section id="content">
		<div class="container-fluid" id="content-wrapper">
			<div class="span12">
				<?php include_once 'header.php'; ?>


				<?php
    $dbhost='localhost';
    $dbuser='root';
    $dbpass='';
    $dbname='bansoss';
    $db=new mysqli($dbhost,$dbuser,$dbpass,$dbname);

    // $sql = "SELECT  
    // a.nama as name, b.nama_kriteria as criteria, c.nilai as val,b.bobot_kriteria as bobot, b.atribut as attribute  
    // FROM
    // tbl_warga a, tbl_kriteria b, tbl_himpunan c,  tbl_klasifikasi d 
    
	// where  
	// a.id_warga=d.id_warga and c.id_himpunan=d.id_himpunan and b.id_kriteria=c.id_kriteria
	
	// order by val desc";
	
	
	$criterias = $db->query("SELECT * FROM tbl_kriteria ORDER BY id_kriteria ASC");
	$result_criteria = mysqli_fetch_all($criterias);

	$datas = $db->query("SELECT k.id as id, w.nama AS nama, u.nilai AS usia, 
	t.nilai AS tanggungan,
	p.nilai AS pendapatan,  
	s.nilai AS status_pernikahan,
    cru.bobot_kriteria AS val_usia,
    crs.bobot_kriteria AS val_status,
    crp.bobot_kriteria AS val_pend,
    crt.bobot_kriteria AS val_tangg
	FROM tbl_klasifikasi k 
	LEFT JOIN tbl_warga w ON k.warga_id = w.id_warga 
	LEFT JOIN tbl_usia u ON k.usia_id = u.id 
	LEFT JOIN tbl_status_pernikahan s ON k.status_id = s.id 
	LEFT JOIN tbl_pendapatan p ON k.pendapatan_id = p.id 
	LEFT JOIN tbl_tanggungan t ON k.tanggungan_id = t.id 
    
    LEFT JOIN tbl_kriteria cru ON u.id_kriteria = cru.id_kriteria 
	LEFT JOIN tbl_kriteria crs ON s.id_kriteria = crs.id_kriteria 
	LEFT JOIN tbl_kriteria crp ON p.id_kriteria = crp.id_kriteria 
	LEFT JOIN tbl_kriteria crt ON t.id_kriteria = crt.id_kriteria 
	ORDER BY id ASC");
	$result_datax = mysqli_fetch_all($datas);
	
	$data_yiij = $db->query("SELECT k.id as id, w.nama AS nama, u.nilai AS usia, 
	t.nilai AS tanggungan,
	p.nilai AS pendapatan,  
	s.nilai AS status_pernikahan 
	FROM tbl_klasifikasi k 
	LEFT JOIN tbl_warga w ON k.warga_id = w.id_warga 
	LEFT JOIN tbl_usia u ON k.usia_id = u.id 
	LEFT JOIN tbl_status_pernikahan s ON k.status_id = s.id 
	LEFT JOIN tbl_pendapatan p ON k.pendapatan_id = p.id 
	LEFT JOIN tbl_tanggungan t ON k.tanggungan_id = t.id 
	ORDER BY id ASC");
	$result_yiij = mysqli_fetch_all($data_yiij);

	// var_dump($result_datax);
	// function Rij($i, $j)
	// {
	// 	$resulti =  pow($i,2);
	// 	$resultj = sqrt($j,4);
	// 	$resultRij = round($resulti) / $resultj;
	// 	echo $resultRij;
	// 	// return $resultRij;
	// }
	// foreach ($result_yiij as $i => $value) {
	// 	// var_dump($value);
	// 	$valyiij = $value[2] + $value[3] + $value[4] + $value[5];
	// 	// if (!$value[0] && !$value[1]) {
	// 		var_dump(pow($valyiij,2));
	// 	// }
	// }
	// var_dump($nilai_kuadrat);
	// var_dump('this '.$nilai_kuadrat);
    // $result=$db->query($sql);
    // $data=array();
    // $kriterias=array();
// var_dump($kriterias);

//     $bobot=array();
//     $atribut=array();
//     $nilai_kuadrat=array();
//   while($row=$result->fetch_object()){

//     if(!isset($data[$row->name])){
//     $data[$row->name]=array();
//     }
//     if(!isset($data[$row->name][$row->criteria])){
//     $data[$row->name][$row->criteria]=array();
//     }
//     if(!isset($nilai_kuadrat[$row->criteria])){
//     $nilai_kuadrat[$row->criteria]=0;
//     }
//     $bobot[$row->criteria]=$row->bobot;
//     $atribut[$row->criteria]=$row->attribute;
//     $data[$row->name][$row->criteria]=$row->val;

//     $nilai_kuadrat[$row->criteria]+=pow($row->val,2);
//     $kriterias[]=$row->criteria;
//   }
//   $kriteria=array_unique($kriterias);
// //   var_dump($data);

//   $jml_kriteria=count($kriteria);

?>

				<div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h3>Evaluation Matrix (x<sub>ij</sub>)</h3>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th rowspan="4">No</th> 
												      <th rowspan="3">Alternatif</th>
												      <th rowspan="3">nama</th>
												      <th colspan='<?php echo count($result_criteria) ?>'><center>Keriteria</center></th>
												    </tr>
												    <tr>
												    <?php 
												      foreach ($result_criteria as $k) :
														// var_dump($k[1])
												    ?>
													<th><?= $k[1];?></th>
													<?php
												      endforeach
												    ?>
												    </tr>
												    <tr>
												    <?php 
												    for ($n=1; $n<=count($result_criteria); $n++) { 
												      echo "<th>C{$n}</th>";
												    }
												     ?>
												    </tr>
												  </thead>
												  <tbody>
												    <?php 
												    $i=0;
												    foreach ($result_datax as $item) :
												    ?>
													<tr>

													<td><?= (++$i) ?></td>
													<td>A<?= $i ?></td>
													<td><?= $item[1] ?></td>
													<td><?= $item[2] ?></td>
													<td><?= $item[3] ?></td>
													<td><?= $item[4] ?></td>
													<td><?= $item[5] ?></td>
													</tr>
													
													<?php 
													endforeach
													?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div>


				<div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Rating Kinerja Ternormalisasi (r<sub>ij</sub>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
												<thead>
												    <tr>
												      <th rowspan="4">No</th> 
												      <th rowspan="3">Alternatif</th>
												      <th rowspan="3">nama</th>
												      <th colspan='<?php echo count($result_criteria) ?>'><center>Keriteria</center></th>
												    </tr>
												    <tr>
												    <?php 
												      foreach ($result_criteria as $k) :
														// var_dump($k[1])
												    ?>
													<th><?= $k[1];?></th>
													<?php
												      endforeach
												    ?>
												    </tr>
												    <tr>
												    <?php 
												    for ($n=1; $n<=count($result_criteria); $n++) { 
												      echo "<th>C{$n}</th>";
												    }
												     ?>
												    </tr>
												</thead>
												  <tbody>
												    <?php 
												    $i=0;
												    foreach ($result_datax as $item) :
														// foreach ($result_yiij as $data => $value) {
															# code...
															$cru += pow($item[2],2);
															$crs += pow($item[3],2);
															$crp += pow($item[4],2);
															$crt += pow($item[5],2);

															$cru_pow += pow($cru,0.5);
															$crs_pow += pow($crs,0.5);
															$crp_pow += pow($crp,0.5);
															$crt_pow += pow($crt,0.5);
															// $valyiij_pow = pow($valyiij,0.5);
												    ?>
													<tr>

													<td><?= (++$i) ?></td>
													<td>A<?= $i ?></td>
													<td><?= $item[1] ?></td>
													<td><?= 
														round($item[2]/sqrt($cru_pow), 4) 
													?></td>
													<td><?= round($item[3]/sqrt($crp_pow), 4)   ?></td>
													<td><?= round($item[4]/sqrt($crt_pow), 4)  ?></td>
													<td><?= round($item[5]/sqrt($crs_pow), 4)  ?></td>
													</tr>
													
													<?php 
														// }
													endforeach
													?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
        	    <hr class="hr-normal"/>
					</div>
				</div>



				 <div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Rating Bobot Ternormalisasi(y<sub>ij</sub>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th rowspan="4">No</th> 
												      <th rowspan="3">Alternatif</th>
												      <th rowspan="3">nama</th>
												      <th colspan='<?php echo $jml_kriteria ?>'><center>Keriteria</center></th>
												    </tr>
												    <tr>
												    <?php 
												      foreach ($kriteria as $k) {
												        echo "<th>{$k}</th>";
												      }
												    ?>
												    </tr>
												    <tr>
												    <?php 
												    for ($n=1; $n<=$jml_kriteria; $n++) { 
												      echo "<th>C{$n}</th>";
												    }
												     ?>
												    </tr>
												  </thead>
												  <tbody>
												    <?php 
												    $i=0;
												    foreach ($data as $nama=>$krit) {
												      echo "<tr>
												      <td>".(++$i)."</td>
												      <th>A{$i}</th>
												      <th>{$nama}</th>";
												      foreach ($kriteria as $k) {
												        $y[$k][$i-1]=round(($krit[$k]/sqrt($nilai_kuadrat[$k])),4)*$bobot[$k];
      													echo "<td align='center'>".$y[$k][$i-1]."</td>";
												      }
												      echo "</tr>";
												    }
												    ?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
  		          <hr class="hr-normal"/>
					</div>
				</div> 



				 <div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Solusi Ideal positif (A<sup>+</sup>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th colspan='<?php echo $jml_kriteria ?>'><center>Keriteria</center></th>
												    </tr>
												    <tr>
												    <?php 
												      foreach ($kriteria as $k) {
												        echo "<th>{$k}</th>";
												      }
												    ?>
												    </tr>
												    <tr>
												    <?php  
												    for ($n=1; $n<=$jml_kriteria; $n++) { 
												      echo "<th>y<sub>{$n}</sub><sup>+</sup></th>";
												    }
												    ?>
												    </tr>
												  </thead>
												  <tbody>
												  <tr>
											  	<?php 
											    $yplus=array();
											    foreach ($kriteria as $k) {
											    	$yplus[$k]=($atribut[$k]=='benefit'?max($y[$k]):min($y[$k]));
											    	echo "<th>{$yplus[$k]}</th>";
											    }
											    ?>
												  </tr>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div> 


				 <div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Solusi Ideal Negatif (A<sup>-</sup>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th colspan='<?php echo $jml_kriteria ?>'><center>Keriteria</center></th>
												    </tr>
												    <tr>
												    <?php 
												      foreach ($kriteria as $k) {
												        echo "<th>{$k}</th>";
												      }
												    ?>
												    </tr>
												    <tr>
												    <?php  
												    for ($n=1; $n<=$jml_kriteria; $n++) { 
												      echo "<th>y<sub>{$n}</sub><sup>-</sup></th>";
												    }
												    ?>
												    </tr>
												  </thead>
												  <tbody>
												  <tr>
											  	<?php 
											    $ymin=array();
											    foreach ($kriteria as $k) {
											    	$ymin[$k]=($atribut[$k]=='cost'?max($y[$k]):min($y[$k]));
											    	echo "<th>{$ymin[$k]}</th>";
											    }
											    ?>
												  </tr>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div> 


 
				<div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Jarak positif (D <sub>i</sub><sup>+</sup>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th>No</th>
												      <th>Alternatif</th>
												      <th>Nama</th>
												      <th>D</th>
												    </tr>												    
												  </thead>
												  <tbody>
												  <?php 
												  $i=0;
												  $dplus=array();
												  foreach ($data as $nama => $krit) {
												  	echo "<tr>
												  	<td>".(++$i)."</td>
												  	<th>A{$i}</th>
												  	<td>{$nama}</td>";
												  	foreach ($kriteria as $k) {
												  		if (!isset($dplus[$i-1])) $dplus[$i-1]=0;
												  		$dplus[$i-1]+=pow($yplus[$k]-$y[$k][$i-1],2);
												  	}
												  	echo "<td>".round(sqrt($dplus[$i-1]),6)."</td>
												  	</tr>";
												  }
												  ?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div> 


				 <div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Jarak positif (D <sub>i</sub><sup>-</sup>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th>No</th>
												      <th>Alternatif</th>
												      <th>Nama</th>
												      <th>D</th>
												    </tr>												    
												  </thead>
												  <tbody>
												  <?php 
												  $i=0;
												  $dmin=array();
												  foreach ($data as $nama => $krit) {
												  	echo "<tr>
												  	<td>".(++$i)."</td>
												  	<th>A{$i}</th>
												  	<td>{$nama}</td>";
												  	foreach ($kriteria as $k) {
												  		if (!isset($dmin[$i-1])) $dmin[$i-1]=0;
												  		$dmin[$i-1]+=pow($ymin[$k]-$y[$k][$i-1],2);
												  	}
												  	echo "<td>".round(sqrt($dmin[$i-1]),6)."</td>
												  	</tr>";
												  }
												  ?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div> 


				 <div class="row-fluid">
					<div class="span12 box">
						<div class="box-content">
							<div class="row-fluid">
								<div class='span12 box bordered-box orange-border' style='margin-bottom: 0;'>
								<h2>Nilai Preferensi (V <sub>i</sub>)</h2>
									<div class="box-content box-no-padding">
										<div class="responsive-table">
											<form>
												<table class="table" style="margin-bottom: 0;">
													<thead>
												    <tr>
												      <th>No</th>
												      <th>Alternatif</th>
												      <th>Nama</th>
												      <th>V</th>
												    </tr>												    
												  </thead>
												  <tbody>
												  <?php 
												  $i=0;
												  $V=array();
												  foreach ($data as $nama => $krit) {
												  	echo "<tr>
												  	<td>".(++$i)."</td>
												  	<th>A{$i}</th>
												  	<td>{$nama}</td>";
												  	foreach ($kriteria as $k) {
												  		$V[$i-1]=$dmin[$i-1]/($dmin[$i-1]+$dplus[$i-1]);
												  	}
												  	echo "<td>{$V[$i-1]}</td></tr>";
												  }
												  ?>
												  </tbody>
												</table>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix"></div>
            	<hr class="hr-normal"/>
					</div>
				</div> 

			</div>
		</div>
	</section>

	<?php include_once 'footer.php'; ?>
