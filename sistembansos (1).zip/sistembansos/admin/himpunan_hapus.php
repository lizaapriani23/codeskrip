<?php
include '../inc/koneksi.php';



$id = isset($_GET['id_himpunan']) ? $_GET['id_himpunan'] : '';
$query = mysqli_query($konek, "DELETE FROM tbl_usia WHERE id='$id'") or die(mysql_error());

$id = isset($_GET['id_himpunan']) ? $_GET['id_himpunan'] : '';
$query = mysqli_query($konek, "DELETE FROM tbl_status_pernikahan WHERE id='$id'") or die(mysql_error());

$id = isset($_GET['id_himpunan']) ? $_GET['id_himpunan'] : '';
$query = mysqli_query($konek, "DELETE FROM tbl_tanggungan WHERE id='$id'") or die(mysql_error());

$id = isset($_GET['id_himpunan']) ? $_GET['id_himpunan'] : '';
$query = mysqli_query($konek, "DELETE FROM tbl_pendapatan WHERE id='$id'") or die(mysql_error());
if ($query) {
?>
	<script>
		alert('Data himpunan berhasil dihapus');
		document.location = 'himpunan.php';
	</script>
<?php
}
?>