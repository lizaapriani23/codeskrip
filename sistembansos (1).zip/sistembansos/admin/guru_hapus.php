<?php 
include '../inc/koneksi.php';

$id = isset($_GET['id_warga']) ? $_GET['id_warga']:'';
$query = mysqli_query($konek,"DELETE FROM tbl_warga WHERE id_warga='$id'") or die(mysql_error());
if ($query) {
?>
	<script>
		alert('Data warga berhasil dihapus');
		document.location='guru.php';
	</script>
<?php
}
?>