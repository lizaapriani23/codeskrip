-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2022 at 12:50 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bansos`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bobot`
--

CREATE TABLE `tbl_bobot` (
  `id_bobot` int(10) NOT NULL,
  `nama_bobot` varchar(50) NOT NULL,
  `nilai` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_bobot`
--

INSERT INTO `tbl_bobot` (`id_bobot`, `nama_bobot`, `nilai`) VALUES
(1, 'Tidak Penting', 1),
(2, 'Cukup Penting', 2),
(3, 'Penting', 3),
(4, 'Sangat Penting', 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_klasifikasi`
--

CREATE TABLE `tbl_klasifikasi` (
  `id` int(11) NOT NULL,
  `warga_id` int(11) NOT NULL,
  `pendapatan_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `tanggungan_id` int(11) NOT NULL,
  `usia_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_klasifikasi`
--

INSERT INTO `tbl_klasifikasi` (`id`, `warga_id`, `pendapatan_id`, `status_id`, `tanggungan_id`, `usia_id`, `created_at`) VALUES
(2, 12, 2, 2, 2, 6, '2022-09-27 17:27:44'),
(9, 13, 1, 1, 1, 1, '2022-10-26 06:13:22'),
(40, 14, 1, 1, 2, 1, '2022-10-26 10:44:45'),
(43, 16, 2, 1, 1, 1, '2022-10-26 20:55:05'),
(44, 11, 1, 1, 2, 7, '2022-10-26 23:42:45');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kriteria`
--

CREATE TABLE `tbl_kriteria` (
  `id_kriteria` int(10) NOT NULL,
  `nama_kriteria` varchar(50) CHARACTER SET latin1 NOT NULL,
  `atribut` enum('benefit','cost','','') CHARACTER SET latin1 NOT NULL,
  `bobot_kriteria` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kriteria`
--

INSERT INTO `tbl_kriteria` (`id_kriteria`, `nama_kriteria`, `atribut`, `bobot_kriteria`) VALUES
(6, 'Usia', 'benefit', 4),
(7, 'Tanggungan', 'benefit', 2),
(8, 'Pendapatan', 'cost', 3),
(9, 'Status Pernikahan', 'benefit', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pendapatan`
--

CREATE TABLE `tbl_pendapatan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_pendapatan`
--

INSERT INTO `tbl_pendapatan` (`id`, `nama`, `nilai`, `id_kriteria`) VALUES
(1, 'lebih besar dari 4 juta', 1, 8),
(2, '2 sampai 3 juta', 2, 8),
(3, '1 juta sampai kurang dari 2 juta', 3, 8),
(4, 'kurang dari 1 juta', 4, 8),
(5, 'tidak ada gaji yang diterima tiap bulan', 5, 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status_pernikahan`
--

CREATE TABLE `tbl_status_pernikahan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_status_pernikahan`
--

INSERT INTO `tbl_status_pernikahan` (`id`, `nama`, `nilai`, `id_kriteria`) VALUES
(1, 'menikah', 1, 9),
(2, 'janda', 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tanggungan`
--

CREATE TABLE `tbl_tanggungan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_tanggungan`
--

INSERT INTO `tbl_tanggungan` (`id`, `nama`, `nilai`, `id_kriteria`) VALUES
(1, 'antara 0 sampai 1 anak', 1, 7),
(2, 'antara 2 sampai 3 anak', 2, 7),
(3, 'antara 4 sampai 5 anak', 3, 7),
(4, 'antara 6 sampai 7 anak', 4, 7),
(5, 'lebih dari 8', 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `nama`) VALUES
(1, 'admin', 'admin', 'Liza Apriani');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usia`
--

CREATE TABLE `tbl_usia` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai` int(11) NOT NULL,
  `id_kriteria` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_usia`
--

INSERT INTO `tbl_usia` (`id`, `nama`, `nilai`, `id_kriteria`) VALUES
(1, 'antara 30 sampai 39', 1, 6),
(2, 'antara 40 sampai 49', 2, 6),
(3, 'antara 50 sampai 59', 3, 6),
(4, 'antara 60 sampai 69', 4, 6),
(5, 'antara 70 sampai 79', 5, 6),
(6, 'antara 80 sampai 89', 6, 6),
(7, 'lebih dari 90', 7, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_warga`
--

CREATE TABLE `tbl_warga` (
  `id_warga` int(10) NOT NULL,
  `nik` varchar(16) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `rt` varchar(2) NOT NULL,
  `rw` varchar(2) NOT NULL,
  `jalan` text DEFAULT NULL,
  `kepala_keluarga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_warga`
--

INSERT INTO `tbl_warga` (`id_warga`, `nik`, `nama`, `rt`, `rw`, `jalan`, `kepala_keluarga`) VALUES
(11, '111111111', 'Fitri Maria', '03', '12', 'jalan riau', 'bapak 1'),
(12, 'asdahd', 'Ijah Hodijah', '02', '12', 'jsdbajb', 'jasdjaj'),
(13, '21211', 'Ade Herniati', '2', '1', 'sjdaha', 'asdha'),
(14, '123123', 'Suryati', '1', '2', 'kefk', 'sdajh'),
(15, '23232', 'Zubaedah', '1', '1', 'WEFEWFW', 'FDF'),
(16, '3201380403000060', 'Siti Rahma', '3', '7', 'Sawah Asep', 'Abdul');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bobot`
--
ALTER TABLE `tbl_bobot`
  ADD PRIMARY KEY (`id_bobot`);

--
-- Indexes for table `tbl_klasifikasi`
--
ALTER TABLE `tbl_klasifikasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kriteria`
--
ALTER TABLE `tbl_kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `tbl_pendapatan`
--
ALTER TABLE `tbl_pendapatan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_status_pernikahan`
--
ALTER TABLE `tbl_status_pernikahan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tanggungan`
--
ALTER TABLE `tbl_tanggungan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_usia`
--
ALTER TABLE `tbl_usia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_warga`
--
ALTER TABLE `tbl_warga`
  ADD PRIMARY KEY (`id_warga`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bobot`
--
ALTER TABLE `tbl_bobot`
  MODIFY `id_bobot` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_klasifikasi`
--
ALTER TABLE `tbl_klasifikasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tbl_kriteria`
--
ALTER TABLE `tbl_kriteria`
  MODIFY `id_kriteria` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_pendapatan`
--
ALTER TABLE `tbl_pendapatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_status_pernikahan`
--
ALTER TABLE `tbl_status_pernikahan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_tanggungan`
--
ALTER TABLE `tbl_tanggungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_usia`
--
ALTER TABLE `tbl_usia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_warga`
--
ALTER TABLE `tbl_warga`
  MODIFY `id_warga` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
